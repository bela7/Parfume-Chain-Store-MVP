package Presenter;

import Model.Parfum;
import Model.ParfumMagazin;
import Model.ParfumMagazinPersistent;
import Model.ParfumPersistent;
import View.IAngajat;

import java.util.List;

public class AngajatPresenter {
    private IAngajat view;
    private ParfumPersistent parfumPersistent;
    private ParfumMagazinPersistent parfumMagazinPersistent;

    public AngajatPresenter(IAngajat view) {
        this.view = view;
        this.parfumPersistent = new ParfumPersistent();
        this.parfumMagazinPersistent = new ParfumMagazinPersistent();
    }


    public void addParfum() {
        int idParfum = view.getIdParfum();
        int stoc = view.getStoc();
        int angajatIdMagazin = view.getIdMagazin();

        if (idParfum != -1 && stoc != -1) {
            boolean success = parfumMagazinPersistent.createParfumMagazin(idParfum, angajatIdMagazin, stoc);
            if (success) {
                view.showParfumAddedSuccessMessage();
                displayParfumList();
            } else {
                view.showFailedToAddParfumMessage();
            }
        } else {
            view.showIdStocInvalidMessage();
        }
    }


    public void updateParfum() {
        int idParfum = view.getIdParfum();
        int stoc = view.getStoc();
        int angajatIdMagazin = view.getIdMagazin();

        if (idParfum != -1 && stoc != -1) {
            boolean success = parfumMagazinPersistent.updateParfumMagazinStock(idParfum, angajatIdMagazin, stoc);
            if (success) {
                view.showParfumUpdatedSuccessMessage();
                displayParfumList();
            } else {
                view.showFailedToUpdateParfumMessage();
            }
        } else {
            view.showIdStocInvalidMessage();
        }
    }

    public void deleteParfum() {
        int selectedParfumId = view.getSelectedParfumId();
        int angajatIdMagazin = view.getIdMagazin();

        if (selectedParfumId == -1) {
            view.showParfumNotSelectedMessage();
            return;
        }

        boolean success = parfumMagazinPersistent.deleteParfumMagazin(selectedParfumId,angajatIdMagazin);

        if (success) {
            view.showParfumDeletedSuccessMessage();
            displayParfumList();
        } else {
            view.showFailedToDeleteParfumMessage();
        }
    }

    public void addNewParfum() {
        int idParfum = view.getNewIdParfum();
        String nume = view.getNewNume();
        String producator = view.getNewProducator();
        double pret = view.getNewPret();
        String descriere = view.getNewDescriere();
        int stoc = view.getNewStoc();
        int angajatIdMagazin = view.getIdMagazin();

        if (idParfum != -1 && pret != -1 && stoc != -1 && !nume.isEmpty() && !producator.isEmpty() && !descriere.isEmpty()) {
            Parfum newParfum = new Parfum(idParfum, nume, producator, pret, descriere);
            ParfumPersistent parfumPersistent = new ParfumPersistent();
            boolean createdParfum = parfumPersistent.create(newParfum);

            if (createdParfum) {
                boolean createdParfumMagazin = parfumMagazinPersistent.createParfumMagazin(idParfum, angajatIdMagazin, stoc);
                if (createdParfumMagazin) {
                    view.showParfumAddedSuccessMessage();
                    displayParfumList();
                } else {
                    view.showFailedToAddParfumMessage();
                }
            } else {
                view.showFailedToAddParfumMessage();
            }
        } else {
            view.showIdStocInvalidMessage();
        }
    }



    public void displayParfumList() {
        List<ParfumMagazin> parfumuriMagazin = parfumPersistent.getAllParfumuriForMagazin(view.getIdMagazin());

        Object[][] parfumList = new Object[parfumuriMagazin.size()][7];
        for (int i = 0; i < parfumuriMagazin.size(); i++) {
            ParfumMagazin pm = parfumuriMagazin.get(i);
            Parfum parfum = pm.getParfum();
            parfumList[i][0] = parfum.getIdParfum();
            parfumList[i][1] = parfum.getNume();
            parfumList[i][2] = parfum.getProducator();
            parfumList[i][3] = parfum.getPret();
            parfumList[i][4] = parfum.getDescriere();
            parfumList[i][5] = pm.getStoc();
        }

        view.displayParfumList(parfumList);
    }

    public void handleGetAllProducators() {
        int idMagazin = view.getIdMagazin();
        List<String> producators = parfumPersistent.getAllProducators(idMagazin);
        view.setProducatorList(producators);
    }

    public void handleFilterParfums() {
        Double priceMin = null;
        Double priceMax = null;
        String producator = null;
        Boolean disponibil = null;

        String priceMinText = view.getPriceMin();
        String priceMaxText = view.getPriceMax();
        int idMagazin = view.getIdMagazin();

        if (!priceMinText.isEmpty()) {
            priceMin = Double.parseDouble(priceMinText);
        }

        if (!priceMaxText.isEmpty()) {
            priceMax = Double.parseDouble(priceMaxText);
        }

        if (!view.getSelectedProducator().isEmpty()) {
            producator = view.getSelectedProducator();
        }

        if (view.isDisponibilSelected()) {
            disponibil = view.isDisponibilSelected();
        }

        List<ParfumMagazin> filteredParfums = parfumPersistent.filterParfums(idMagazin, priceMin, priceMax, producator, disponibil);

        Object[][] parfumList = new Object[filteredParfums.size()][6];
        for (int i = 0; i < filteredParfums.size(); i++) {
            ParfumMagazin pm = filteredParfums.get(i);
            Parfum parfum = pm.getParfum();
            parfumList[i][0] = parfum.getIdParfum();
            parfumList[i][1] = parfum.getNume();
            parfumList[i][2] = parfum.getProducator();
            parfumList[i][3] = parfum.getPret();
            parfumList[i][4] = parfum.getDescriere();
            parfumList[i][5] = pm.getStoc();
        }

        view.displayParfumList(parfumList);
    }



}

