package Presenter;

import Model.*;
import View.IManager;

import java.util.List;
import java.util.ArrayList;

public class ManagerPresenter {
    private IManager view;
    private ParfumPersistent parfumPersistent;
    private MagazinPersistent magazinPersistent;

    public ManagerPresenter(IManager view) {
        this.view = view;
        this.parfumPersistent = new ParfumPersistent();
        this.magazinPersistent = new MagazinPersistent();

    }


    public List<String> getAllMagazinNames() {
        List<Magazin> magazine = magazinPersistent.getAll();
        List<String> magazinNames = new ArrayList<>();

        for (Magazin magazin : magazine) {
            magazinNames.add(magazin.getNume());
        }

        return magazinNames;
    }

    public int getMagazinIdByName() {
        String selectedMagazinName = view.getSelectedMagazinName();
        List<Magazin> magazine = magazinPersistent.getAll();

        for (Magazin magazin : magazine) {
            if (magazin.getNume().equals(selectedMagazinName)) {
                return magazin.getIdMagazin();
            }
        }
        return -1;
    }
    public void handleGetAllProducators() {
        int idMagazin = view.getIdMagazin();
        List<String> producators = parfumPersistent.getAllProducators(idMagazin);
        view.setProducatorList(producators);
    }

    public void handleFilterParfums() {
        Double priceMin = null;
        Double priceMax = null;
        String producator = null;
        Boolean disponibil = null;

        String priceMinText = view.getPriceMin();
        String priceMaxText = view.getPriceMax();

        int idMagazin = view.getIdMagazin();
        if (!priceMinText.isEmpty()) {
            priceMin = Double.parseDouble(priceMinText);
        }

        if (!priceMaxText.isEmpty()) {
            priceMax = Double.parseDouble(priceMaxText);
        }

        if (!view.getSelectedProducator().isEmpty()) {
            producator = view.getSelectedProducator();
        }

        if (view.isDisponibilSelected()) {
            disponibil = view.isDisponibilSelected();
        }

        List<ParfumMagazin> filteredParfums = parfumPersistent.filterParfums(idMagazin, priceMin, priceMax, producator, disponibil);

        updateParfumList(filteredParfums);
    }


    public void handleSortParfumsByName() {
        boolean ascending = view.isSortByNameAscending();
        int idMagazin = view.getIdMagazin();
        List<ParfumMagazin> sortedParfums = parfumPersistent.getSortedParfumsByName(idMagazin, ascending);

        updateParfumList(sortedParfums);
    }

    public void handleSortParfumsByPrice() {
        boolean ascending = view.isSortByPriceAscending();
        int idMagazin = view.getIdMagazin();
        List<ParfumMagazin> sortedParfums = parfumPersistent.getSortedParfumsByPrice(idMagazin, ascending);

        updateParfumList(sortedParfums);
    }


    public void handleSearchParfumByName() {
        String parfumName = view.getEnteredParfumName();
        Parfum parfum = parfumPersistent.readByName(parfumName);

        if (parfum != null) {
            String parfumDetails = String.format("ID: %d\nNume: %s\nProducator: %s\nPret: %.2f\nDescriere: %s",
                    parfum.getIdParfum(), parfum.getNume(),
                    parfum.getProducator(), parfum.getPret(), parfum.getDescriere());
            view.showPerfumeDetailsByName(parfumDetails);
        } else {
            view.showParfumNotFoundMessage();
        }
    }

    public void displayParfumList() {
        int idMagazin = view.getIdMagazin();
        List<ParfumMagazin> parfumuriMagazin = parfumPersistent.getAllParfumuriForMagazin(idMagazin);

        // Transformare în tabel
        Object[][] parfumList = new Object[parfumuriMagazin.size()][7];
        for (int i = 0; i < parfumuriMagazin.size(); i++) {
            ParfumMagazin pm = parfumuriMagazin.get(i);
            Parfum parfum = pm.getParfum();
            parfumList[i][0] = parfum.getIdParfum();
            parfumList[i][1] = parfum.getNume();
            parfumList[i][2] = parfum.getProducator();
            parfumList[i][3] = parfum.getPret();
            parfumList[i][4] = parfum.getDescriere();
            parfumList[i][5] = pm.getStoc();
        }

        view.displayParfumList(parfumList);
    }
    private void updateParfumList(List<ParfumMagazin> parfumMagazinList) {
        Object[][] parfumList = new Object[parfumMagazinList.size()][6];
        for (int i = 0; i < parfumMagazinList.size(); i++) {
            ParfumMagazin pm = parfumMagazinList.get(i);
            Parfum parfum = pm.getParfum();
            parfumList[i][0] = parfum.getIdParfum();
            parfumList[i][1] = parfum.getNume();
            parfumList[i][2] = parfum.getProducator();
            parfumList[i][3] = parfum.getPret();
            parfumList[i][4] = parfum.getDescriere();
            parfumList[i][5] = pm.getStoc();
        }

        view.displayParfumList(parfumList);
    }


}

