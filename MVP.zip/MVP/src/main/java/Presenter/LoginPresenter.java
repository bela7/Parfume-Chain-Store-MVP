package Presenter;

import Model.Utilizator;
import Model.UtilizatorPersistent;
import View.ILogin;

public class LoginPresenter {
    private ILogin view;
    private UtilizatorPersistent utilizatorPersistent;

    public LoginPresenter(ILogin view) {
        this.view = view;
        this.utilizatorPersistent = new UtilizatorPersistent();
    }

    public void autentificare() {
        String user = view.getUser();
        String parola = view.getParola();

        Utilizator utilizator = utilizatorPersistent.cautareUtilizator(user, parola);

        if (utilizator != null) {
            String rol = utilizator.getRol();

            if (rol.equals("administrator")) {
                view.setAdministratorGUI(user);
            } else if (rol.equals("manager")) {
                view.setManagerGUI(user);
            } else if (rol.equals("angajat")) {
                view.setAngajatGUI(user, utilizator.getIdMagazin());
            }
        } else {
            view.mesajEroare();
        }
    }
}
