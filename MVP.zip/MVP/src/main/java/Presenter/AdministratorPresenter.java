package Presenter;

import Model.Utilizator;
import Model.UtilizatorPersistent;
import View.IAdministrator;

import java.util.List;


public class AdministratorPresenter {
        private IAdministrator view;
        private UtilizatorPersistent utilizatorPersistent;
        private Utilizator utilizator;

        public AdministratorPresenter(IAdministrator view) {
            this.view = view;
            this.utilizatorPersistent = new UtilizatorPersistent();
            this.utilizator = new Utilizator();
        }

        public void addUser() {
                Utilizator utilizator = new Utilizator();
                int userId = view.getUserId();
                String username=view.getUserName();
                String rol = view.getRol();
                String parola= view.getPassword();
                int idMagazin= view.getIdMagazin();

                utilizator.setUserId(userId);
                utilizator.setUser(username);
                utilizator.setParola(parola);
                utilizator.setRol(rol);
                utilizator.setIdMagazin(idMagazin);

                boolean success = utilizatorPersistent.create(utilizator);

                if (success) {
                    view.showUserAddedSuccessMessage();
                    displayUserList();
                } else {
                view.showFailedToAddUserMessage();
                }
            }

        public void updateUser() {
                int selectedUserId = view.getSelectedUserId();

                if (selectedUserId == -1) {
                    view.showSelectUserToUpdateMessage();
                    return;
                }

                Utilizator utilizator = new Utilizator();
                int userId = view.getUserId();
                String username=view.getUserName();
                String rol = view.getRol();
                String parola= view.getPassword();
                int idMagazin= view.getIdMagazin();

                utilizator.setUserId(userId);
                utilizator.setUser(username);
                utilizator.setParola(parola);
                utilizator.setRol(rol);
                utilizator.setIdMagazin(idMagazin);

                 boolean success = utilizatorPersistent.update(utilizator);

                if (success) {
                    view.showUserUpdatedSuccessMessage();
                    displayUserList();
                } else {
                    view.showFailedToUpdateUserMessage();
                }
            }


        public void deleteUser() {
                int selectedUserId = view.getSelectedUserId();

                if (selectedUserId == -1) {
                    view.showSelectUserToDeleteMessage();
                    return;
                }

                boolean success = utilizatorPersistent.delete(selectedUserId);

                if (success) {
                    view.showUserDeletedSuccessMessage();
                    displayUserList();
                } else {
                    view.showFailedToDeleteUserMessage();
                }
            }


        public void displayUserList() {
            List<Utilizator> utilizatori = utilizatorPersistent.getAll();
            Object[][] users = new Object[utilizatori.size()][5];
            for (int i = 0; i < utilizatori.size(); i++) {
                Utilizator utilizator = utilizatori.get(i);
                users[i][0] = utilizator.getUserId();
                users[i][1] = utilizator.getUser();
                users[i][2] = utilizator.getParola();
                users[i][3] = utilizator.getRol();
                users[i][4] = utilizator.getIdMagazin();
            }
            view.displayUsers(users);
        }




}
