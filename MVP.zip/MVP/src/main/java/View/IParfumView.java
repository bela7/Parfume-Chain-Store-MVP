package View;

import javax.swing.*;
import java.util.List;

public interface IParfumView {
    int getIdMagazin();
    String getSelectedProducator();
    String getPriceMin();
    String getPriceMax();
    boolean isDisponibilSelected();
    int getSelectedParfumId();
    void displayParfumList(Object[][] parfumList);
    void setProducatorList(List<String> producators);
    void showPerfumeDetails (String Parfume);
    Object[] getRowData(JTable table, int row);

}
