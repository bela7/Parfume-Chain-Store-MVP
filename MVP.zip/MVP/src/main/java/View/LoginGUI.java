package View;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import Presenter.LoginPresenter;


public class LoginGUI extends JFrame implements ILogin {
    final private Font mainFont = new Font("Segoe Print", Font.BOLD, 36);
    final private Font font1 = new Font("Segoe Print", Font.BOLD, 22);
    final private Font font3 = new Font("Segoe Print", Font.BOLD, 14);
    final private Font font2 = new Font("Times New Roman", Font.BOLD, 16);
    JTextField tfUser;
    JPasswordField pfPassword;
    Image backgroundImage;

    public LoginGUI() {
        try {
            File file = new File("D:\\CSC\\2nd Semester\\PS\\Lab\\Tema 1\\parfumTest\\background3.jpg");
            backgroundImage = ImageIO.read(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void initialize() {
        /*************** Form Panel ***************/
        JLabel lbLoginForm = new JLabel("SEPHORA", SwingConstants.CENTER);
        lbLoginForm.setFont(mainFont);
        lbLoginForm.setForeground(Color.WHITE);

        JLabel lbUser = new JLabel("Utilizator");
        lbUser.setFont(font1);

        JLabel lbPassword = new JLabel("Parola");
        lbPassword.setFont(font1);

        // Create the text fields
        tfUser = new JTextField();
        tfUser.setFont(font3);
        tfUser.setOpaque(false);
        tfUser.setPreferredSize(new Dimension(100, 20));

        pfPassword = new JPasswordField();
        pfPassword.setFont(font3);
        pfPassword.setOpaque(false);
        pfPassword.setPreferredSize(new Dimension(150, 30));

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(0, 1, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(100, 280, 50, 280));
        formPanel.add(lbLoginForm);
        formPanel.add(lbUser);
        formPanel.add(tfUser);
        formPanel.add(lbPassword);
        formPanel.add(pfPassword);
        formPanel.setOpaque(false);

        LoginPresenter loginPresenter = new LoginPresenter(this);

        /*************** Buttons Panel ***************/
        JButton btnLogin = new JButton("autentificare");
        btnLogin.setFont(font2);
        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loginPresenter.autentificare();
            }
        });

        JButton btnCancel = new JButton("anulare");
        btnCancel.setFont(font2);
        btnCancel.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }

        });

        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new GridLayout(1, 2, 30, 30));
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(0, 280, 100, 280));
        buttonsPanel.add(btnLogin);
        buttonsPanel.add(btnCancel);
        buttonsPanel.setOpaque(false);

        /*************** Initialise the frame ***************/
        getContentPane().setBackground(Color.BLACK);
        setLayout(new BorderLayout());

        // Add the background image
        ImageIcon imageIcon = new ImageIcon(backgroundImage);
        JLabel backgroundLabel = new JLabel(imageIcon);
        backgroundLabel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                Image image = imageIcon.getImage().getScaledInstance(backgroundLabel.getWidth(), backgroundLabel.getHeight(), Image.SCALE_SMOOTH);
                backgroundLabel.setIcon(new ImageIcon(image));
            }
        });
        add(backgroundLabel);

        // Create a transparent panel to hold the form panel and buttons panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setOpaque(false);

        // Add the form panel and buttons panel to the content panel
        contentPanel.add(formPanel, BorderLayout.CENTER);
        contentPanel.add(buttonsPanel, BorderLayout.SOUTH);

        // Add the content panel on top of the background image
        backgroundLabel.setLayout(new BorderLayout());
        backgroundLabel.add(contentPanel);

        JPanel headerPanel = new JPanel();
        headerPanel.setPreferredSize(new Dimension(600, 100));
        headerPanel.setBackground(Color.BLACK);
        headerPanel.setLayout(new BorderLayout());
        headerPanel.add(lbLoginForm, BorderLayout.CENTER);

        add(headerPanel, BorderLayout.NORTH);

        setTitle("Autentificare");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setSize(850, 700);
        setMinimumSize(new Dimension(850, 700));
        setLocationRelativeTo(null);
        setVisible(true);
    }




    @Override
    public String getUser() {
        return tfUser.getText();
    }

    @Override
    public String getParola() {
        return String.valueOf(pfPassword.getPassword());
    }

    @Override
    public void mesajEroare() {
        JOptionPane.showMessageDialog(LoginGUI.this,
                "Utilizator sau parola invalidă",
                "Încearcă din nou",
                JOptionPane.ERROR_MESSAGE);

    }

    @Override
    public void setAdministratorGUI(String user) {
        AdministratorGUI administratorFrame = new AdministratorGUI(user);
        dispose();
    }

    @Override
    public void setManagerGUI(String user) {
        ManagerGUI managerFrame = new ManagerGUI(user);
        dispose();
    }
    @Override
    public void setAngajatGUI(String user, int idMagazin) {
        AngajatGUI angajatGUI = new AngajatGUI(user, idMagazin);
        dispose();
    }


}

