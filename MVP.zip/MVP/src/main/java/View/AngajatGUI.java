package View;

import Presenter.AngajatPresenter;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;


public class AngajatGUI extends JFrame implements IAngajat {
    private JPanel contentPane;
    private JTable table;
    private JTextField textFieldIdParfum;
    private JTextField textFieldStoc;
    private JTextField textFieldPretMin;
    private JTextField textFieldPretMax;
    private JComboBox<String> comboBoxProducator;
    private JCheckBox chckbxDisponibil;
    private JButton btnAdaugaParfum;
    private JButton btnActualizeazaParfum;
    private JButton btnStergeParfum;
    private JButton btnFiltreaza;
    private JButton btnViewDetails;
    private JButton btnAdaugaParfumNou;
    private JTextField txtIdParfum;
    private JTextField txtNume;
    private JTextField txtProducator;
    private JTextField txtPret;
    private JTextArea txtDescriere;
    private JTextField txtStoc;


    private JTextArea area;
    private JTextArea area1;
    private JTextArea textAreaParfumDetails;

    private AngajatPresenter presenter;
    private int idMagazin;


    public AngajatGUI(String user, int idMagazin) {
        this.idMagazin = idMagazin;
        presenter = new AngajatPresenter(this);

        setTitle("Angajat - " + user);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        setBounds(100, 100, 1100, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 60, 800, 490);
        contentPane.add(scrollPane);
        table = new JTable();
        table.setRowHeight(30);
        table.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Times New Roman", Font.BOLD, 16));

        table.setModel(new DefaultTableModel(
                new Object[][] {},
                new String[] {"Id Parfum", "Denumire", "Producător", "Pret", "Descriere", "Stoc"}
        ));

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        scrollPane.setViewportView(table);

        // First part
        JLabel lblIdParfum = new JLabel("Id:");
        lblIdParfum.setBounds(820, 70, 70, 20);
        contentPane.add(lblIdParfum);
        textFieldIdParfum = new JTextField();
        textFieldIdParfum.setBounds(850, 70, 200, 20);
        contentPane.add(textFieldIdParfum);
        textFieldIdParfum.setColumns(10);


        JLabel lblStoc = new JLabel("Stoc:");
        lblStoc.setBounds(820, 100, 70, 20);
        contentPane.add(lblStoc);

        textFieldStoc = new JTextField();
        textFieldStoc.setBounds(850, 100, 200, 20);
        contentPane.add(textFieldStoc);
        textFieldStoc.setColumns(10);

        btnAdaugaParfum = new JButton("Adauga Parfum");
        btnAdaugaParfum.setBounds(830, 130, 220, 23);
        contentPane.add(btnAdaugaParfum);

        btnViewDetails = new JButton("Vizualizează detaliile unui parfum");
        btnViewDetails.setBounds(830, 210, 220, 23);
        contentPane.add(btnViewDetails);


        btnActualizeazaParfum = new JButton("Actualizează Parfum");
        btnActualizeazaParfum.setBounds(830, 160, 220, 23);
        contentPane.add(btnActualizeazaParfum);

        btnStergeParfum = new JButton("Șterge Parfum");
        btnStergeParfum.setBounds(830, 240, 210, 23);
        contentPane.add(btnStergeParfum);

        JLabel lblPretMinim = new JLabel("Preț minim:");
        lblPretMinim.setBounds(840, 320, 100, 20);
        contentPane.add(lblPretMinim);

        textFieldPretMin = new JTextField();
        textFieldPretMin.setBounds(900, 320, 100, 20);
        contentPane.add(textFieldPretMin);
        textFieldPretMin.setColumns(10);


        JLabel lblPretMaxim = new JLabel("Pret maxim:");
        lblPretMaxim.setBounds(840, 360, 100, 20);
        contentPane.add(lblPretMaxim);

        textFieldPretMax = new JTextField();
        textFieldPretMax.setBounds(900, 360, 100, 20);
        contentPane.add(textFieldPretMax);
        textFieldPretMax.setColumns(10);

        JLabel lblProducator = new JLabel("Producător:");
        lblProducator.setBounds(840, 410, 100, 20);
        contentPane.add(lblProducator);

        comboBoxProducator = new JComboBox<String>();
        comboBoxProducator.setBounds(900, 410, 150, 20);
        contentPane.add(comboBoxProducator);
        presenter.handleGetAllProducators();

        JLabel lblDisponibilitate = new JLabel("Disponibilitate:");
        lblDisponibilitate.setBounds(840, 450, 100, 20);
        contentPane.add(lblDisponibilitate);


        chckbxDisponibil = new JCheckBox("Disponibil");
        chckbxDisponibil.setBounds(850, 470, 100, 23);
        chckbxDisponibil.setBackground(Color.WHITE);
        contentPane.add(chckbxDisponibil);

        btnFiltreaza = new JButton("Filtrează");
        btnFiltreaza.setBounds(880, 500, 120, 23);
        contentPane.add(btnFiltreaza);

        area = new JTextArea();
        area.setBounds(820, 310, 250, 220);
        contentPane.add(area);

        area1 = new JTextArea();
        area1.setBounds(820, 200, 250, 70);
        contentPane.add(area1);

        textAreaParfumDetails= new JTextArea();
        textAreaParfumDetails.setBounds(820, 310, 250, 130);
        contentPane.add(textAreaParfumDetails);

        btnAdaugaParfumNou = new JButton("Adauga parfum nou");
        btnAdaugaParfumNou.setBounds(830, 280, 220, 23);

        contentPane.add(btnAdaugaParfumNou);

        btnViewDetails.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    Object[] rowData = getRowData(table, selectedRow);
                    String perfumeDetails = String.format(
                            "ID Parfum: %s\nDenumire: %s\nProducător: %s\nPret: %s\nDescriere: %s\nStoc: %s",
                            rowData[0], rowData[1], rowData[2], rowData[3], rowData[4], rowData[5]
                    );
                    showPerfumeDetails(perfumeDetails);
                } else {
                    showParfumNotSelectedMessage();
                }
            }
        });
        btnAdaugaParfumNou.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame addParfumFrame = new JFrame("Adaugă parfum nou");
                addParfumFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                addParfumFrame.setSize(400, 300);
                addParfumFrame.setLocationRelativeTo(null);
                addParfumFrame.setLayout(new GridLayout(0, 2));

                JLabel lblIdParfum = new JLabel("IdParfum:");
                txtIdParfum = new JTextField();
                JLabel lblNume = new JLabel("Nume:");
                txtNume = new JTextField();
                JLabel lblProducator = new JLabel("Producator:");
                txtProducator = new JTextField();
                JLabel lblPret = new JLabel("Pret:");
                txtPret = new JTextField();
                JLabel lblDescriere = new JLabel("Descriere:");

                txtDescriere = new JTextArea();
                txtDescriere.setLineWrap(true);
                txtDescriere.setWrapStyleWord(true);
                JScrollPane scrollPaneDescriere = new JScrollPane(txtDescriere);
                scrollPaneDescriere.setPreferredSize(new Dimension(200, 300));

                JLabel lblStoc = new JLabel("Stoc:");
                txtStoc = new JTextField();

                addParfumFrame.add(lblIdParfum);
                addParfumFrame.add(txtIdParfum);
                addParfumFrame.add(lblNume);
                addParfumFrame.add(txtNume);
                addParfumFrame.add(lblProducator);
                addParfumFrame.add(txtProducator);
                addParfumFrame.add(lblPret);
                addParfumFrame.add(txtPret);
                addParfumFrame.add(lblDescriere);
                addParfumFrame.add(scrollPaneDescriere);
                addParfumFrame.add(lblStoc);
                addParfumFrame.add(txtStoc);
                Font inputFont = new Font("Times New Roman", Font.PLAIN, 14);
                Font labelFont = new Font("Times New Roman", Font.BOLD, 14);
                int borderWidth = 20;
                addParfumFrame.getRootPane().setBorder(BorderFactory.createEmptyBorder(borderWidth, borderWidth, borderWidth, borderWidth));


                lblIdParfum.setFont(labelFont);
                txtIdParfum.setFont(inputFont);
                lblNume.setFont(labelFont);
                txtNume.setFont(inputFont);
                lblProducator.setFont(labelFont);
                txtProducator.setFont(inputFont);
                lblPret.setFont(labelFont);
                txtPret.setFont(inputFont);
                lblDescriere.setFont(labelFont);
                txtDescriere.setFont(inputFont);
                lblStoc.setFont(labelFont);
                txtStoc.setFont(inputFont);

                JButton btnSubmit = new JButton("Adaugă parfum nou");
                btnSubmit.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
                btnSubmit.setSize(40,20);
                btnSubmit.setFont(labelFont);
                addParfumFrame.add(new JPanel());
                addParfumFrame.add(btnSubmit);

                btnSubmit.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        presenter.addNewParfum();
                        addParfumFrame.dispose();
                    }
                });

                addParfumFrame.setVisible(true);
            }
        });


        btnAdaugaParfum.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                presenter.addParfum();
            }
        });

        btnActualizeazaParfum.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                presenter.updateParfum();
            }
        });

        btnStergeParfum.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                presenter.deleteParfum();
            }
        });

        btnFiltreaza.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                presenter.handleFilterParfums();
            }
        });


        presenter.displayParfumList();
        setVisible(true);
    }

    @Override
    public int getIdParfum() {
        try {
            return Integer.parseInt(textFieldIdParfum.getText());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    @Override
    public int getNewIdParfum() {
        return Integer.parseInt(txtIdParfum.getText());
    }

    @Override
    public String getNewNume() {
        return txtNume.getText();
    }

    @Override
    public String getNewProducator() {
        return txtProducator.getText();
    }

    @Override
    public double getNewPret() {
        return Double.parseDouble(txtPret.getText());
    }

    @Override
    public String getNewDescriere() {
        return txtDescriere.getText();
    }

    @Override
    public int getNewStoc() {
        return Integer.parseInt(txtStoc.getText());
    }

        @Override
    public void setProducatorList(List<String> producators) {
        comboBoxProducator.removeAllItems();
        comboBoxProducator.addItem("Toți producătorii");
        for (String producator : producators) {
            comboBoxProducator.addItem(producator);
        }
    }


    @Override
    public int getStoc() {
        try {
            return Integer.parseInt(textFieldStoc.getText());
        } catch (NumberFormatException e) {
            return -1;
        }
    }


    @Override
    public Object[] getRowData(JTable table, int row) {
        int columnCount = table.getColumnCount();
        Object[] rowData = new Object[columnCount];

        for (int i = 0; i < columnCount; i++) {
            rowData[i] = table.getValueAt(row, i);
        }

        return rowData;
    }




    @Override
    public int getIdMagazin() {
        return idMagazin;
    }

    @Override
    public String getPriceMin() {
        return textFieldPretMin.getText().trim();
    }

    @Override
    public String getPriceMax() {
        return textFieldPretMax.getText().trim();
    }

    @Override
    public String getSelectedProducator() {
        if (comboBoxProducator.getSelectedIndex() > 0) {
            return (String) comboBoxProducator.getSelectedItem();
        }
        return "";
    }

    @Override
    public boolean isDisponibilSelected() {
        return chckbxDisponibil.isSelected();
    }

    @Override
    public int getSelectedParfumId() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            return Integer.parseInt(table.getValueAt(selectedRow, 0).toString());
        } else {
            return -1;
        }
    }
    @Override
    public void showParfumUpdatedSuccessMessage(){
        JOptionPane.showMessageDialog(this, "Parfum actualizat cu succes.");
    }
    @Override
    public void showFailedToUpdateParfumMessage(){
        JOptionPane.showMessageDialog(this, "Eroare la actualizarea parfumului");
    }
    @Override
    public void showParfumNotSelectedMessage(){
        JOptionPane.showMessageDialog(this, "Selectați un parfum pentru a vizualiza detaliile.");
    }
    public void showParfumAddedSuccessMessage(){
        JOptionPane.showMessageDialog(this, "Parfum adăugat cu succes.");
    }
    @Override
    public void showFailedToAddParfumMessage(){
        JOptionPane.showMessageDialog(this, "Eroare la adăugarea parfumului");
    }
    @Override
    public void showParfumDeletedSuccessMessage(){
        JOptionPane.showMessageDialog(this, "Parfum șters cu succes.");
    }
    @Override
    public void showFailedToDeleteParfumMessage(){
        JOptionPane.showMessageDialog(this, "Eroare la ștergerea parfumului");
    }
    @Override
    public void showIdStocInvalidMessage(){
        JOptionPane.showMessageDialog(this, "Id Parfum sau Stoc invalid!");
    }

    @Override
    public void displayParfumList(Object[][] parfumList) {
        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
        tableModel.setRowCount(0);
        for (Object[] row : parfumList) {
            tableModel.addRow(row);
        }
    }

    @Override
    public void showPerfumeDetails(String perfumeDetails) {
        String[] perfumeDetailsArray = perfumeDetails.split("\n");

        String[] columnNames = {
                "ID", "Nume", "Producator", "Pret", "Descriere", "Stoc"
        };

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.5;
        gbc.weighty = 0.5;
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.insets = new Insets(10, 10, 10, 10);

        Font boldFont = new Font("Times New Roman", Font.BOLD, 16);
        Font normalFont = new Font("Times New Roman", Font.PLAIN, 14);

        for (int i = 0; i < columnNames.length; i++) {
            JLabel label = new JLabel(columnNames[i] + ":");
            label.setFont(boldFont);
            panel.add(label, gbc);
            gbc.gridy++;
        }

        gbc.gridx = 1;
        gbc.gridy = 0;
        for (int i = 0; i < perfumeDetailsArray.length; i++) {
            String detail = perfumeDetailsArray[i];
            if (i == 4) { // Description field
                JTextArea descriptionTextArea = new JTextArea(detail.substring(detail.indexOf(':') + 1).trim());
                descriptionTextArea.setFont(normalFont);
                descriptionTextArea.setLineWrap(true);
                descriptionTextArea.setWrapStyleWord(true);
                descriptionTextArea.setEditable(false);
                descriptionTextArea.setOpaque(false);
                descriptionTextArea.setBackground(Color.WHITE);

                JScrollPane scrollPane = new JScrollPane(descriptionTextArea);
                scrollPane.setPreferredSize(new Dimension(450, 100));
                panel.add(scrollPane, gbc);
            } else {
                JLabel label = new JLabel(detail.substring(detail.indexOf(':') + 1).trim());
                label.setFont(normalFont);
                panel.add(label, gbc);
            }
            gbc.gridy++;
        }

        JOptionPane.showMessageDialog(this, panel, "Detalii Parfum", JOptionPane.PLAIN_MESSAGE);
    }



}