package View;

import Presenter.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;



public class ManagerGUI extends JFrame implements IManager{
    private JTable table;
    private JComboBox<String> comboBoxMagazin, comboBoxSortarePret, comboBoxSortareNume, comboBoxProducator;
    private JTextField textFieldCautaDupaNume;
    private JButton btnCauta;
    private JButton btnFiltreaza;
    private JButton btnViewDetails;
    private JCheckBox chckbxDisponibil;

    private ManagerPresenter presenter;

    private JTextArea textAreaParfumDetails;

    private JTextField textFieldPretMin;
    private JTextField textFieldPretMax;
    String user;

    public ManagerGUI(String user1) {
        presenter= new ManagerPresenter(this);
        this.user=user1;
        initUI();
    }

    private void initUI() {
        setTitle("Manager - " + user);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1150, 600);
        setLocationRelativeTo(null);

        JPanel contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Tabel
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 60, 800, 490);
        contentPane.add(scrollPane);
        table = new JTable();
        table.setRowHeight(30);
        table.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Times New Roman", Font.BOLD, 16));

        table.setModel(new DefaultTableModel(
                new Object[][]{},
                new String[]{"Id Parfum", "Denumire", "Producător", "Pret", "Descriere", "Stoc"}
        ));

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        scrollPane.setViewportView(table);

        // ComboBox to select the magazin
        JLabel lblMagazin = new JLabel("Magazin:");
        lblMagazin.setBounds(840, 70, 100, 20);
        contentPane.add(lblMagazin);

        comboBoxMagazin = new JComboBox<String>();
        comboBoxMagazin.setBounds(900, 70, 150, 20);
        contentPane.add(comboBoxMagazin);
        List<String> magazinNames = presenter.getAllMagazinNames();
        setMagazinList(magazinNames);

        // ComboBox for sorting by price
        JLabel lblSortarePret = new JLabel("Sortare preț:");
        lblSortarePret.setBounds(840, 120, 100, 20);
        contentPane.add(lblSortarePret);

        comboBoxSortarePret = new JComboBox<String>();
        comboBoxSortarePret.setBounds(940, 120, 150, 20);
        contentPane.add(comboBoxSortarePret);
        comboBoxSortarePret.addItem("Crescător");
        comboBoxSortarePret.addItem("Descrescător");

        // ComboBox for sorting by name
        JLabel lblSortareNume = new JLabel("Sortare denumire:");
        lblSortareNume.setBounds(840, 150, 100, 20);
        contentPane.add(lblSortareNume);

        comboBoxSortareNume = new JComboBox<String>();
        comboBoxSortareNume.setBounds(940, 150, 150, 20);
        contentPane.add(comboBoxSortareNume);
        comboBoxSortareNume.addItem("Crescător");
        comboBoxSortareNume.addItem("Descrescător");


        // Search by name
        JLabel lblCautaDupaNume = new JLabel("Caută după nume:");
        lblCautaDupaNume.setBounds(840, 200, 100, 20);
        contentPane.add(lblCautaDupaNume);

        textFieldCautaDupaNume = new JTextField();
        textFieldCautaDupaNume.setBounds(940, 200, 150, 20);
        contentPane.add(textFieldCautaDupaNume);

        btnCauta = new JButton("Caută");
        btnCauta.setBounds(950, 230, 80, 23);
        contentPane.add(btnCauta);

        btnCauta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                presenter.handleSearchParfumByName();
            }
        });

        btnViewDetails = new JButton("Vizualizează detaliile unui parfum");
        btnViewDetails.setBounds(830, 260, 220, 23);
        contentPane.add(btnViewDetails);


        JLabel lblPretMinim = new JLabel("Preț minim:");
        lblPretMinim.setBounds(840, 320, 100, 20);
        contentPane.add(lblPretMinim);

        textFieldPretMin = new JTextField();
        textFieldPretMin.setBounds(900, 320, 100, 20);
        contentPane.add(textFieldPretMin);
        textFieldPretMin.setColumns(10);


        JLabel lblPretMaxim = new JLabel("Pret maxim:");
        lblPretMaxim.setBounds(840, 360, 100, 20);
        contentPane.add(lblPretMaxim);

        textFieldPretMax = new JTextField();
        textFieldPretMax.setBounds(900, 360, 100, 20);
        contentPane.add(textFieldPretMax);
        textFieldPretMax.setColumns(10);


        JLabel lblProducator = new JLabel("Producător:");
        lblProducator.setBounds(840, 410, 100, 20);
        contentPane.add(lblProducator);

        comboBoxProducator = new JComboBox<String>();
        comboBoxProducator.setBounds(900, 410, 150, 20);
        contentPane.add(comboBoxProducator);
        presenter.handleGetAllProducators();

        JLabel lblDisponibilitate = new JLabel("Disponibilitate:");
        lblDisponibilitate.setBounds(840, 450, 100, 20);
        contentPane.add(lblDisponibilitate);


        chckbxDisponibil = new JCheckBox("Disponibil");
        chckbxDisponibil.setBounds(850, 470, 100, 23);
        chckbxDisponibil.setBackground(Color.WHITE);
        contentPane.add(chckbxDisponibil);

        btnFiltreaza = new JButton("Filtrează");
        btnFiltreaza.setBounds(880, 500, 120, 23);
        contentPane.add(btnFiltreaza);


        textAreaParfumDetails= new JTextArea();
        textAreaParfumDetails.setBounds(820, 310, 250, 130);
        contentPane.add(textAreaParfumDetails);


        // Event listeners
        comboBoxMagazin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                presenter.handleSortParfumsByName();
            }
        });

        comboBoxSortareNume.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                presenter.handleSortParfumsByName();
            }
        });

        comboBoxSortarePret.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                presenter.handleSortParfumsByPrice();
            }
        });

        btnViewDetails.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    Object[] rowData = getRowData(table, selectedRow);
                    String perfumeDetails = String.format(
                            "ID Parfum: %s\nDenumire: %s\nProducător: %s\nPret: %s\nDescriere: %s\nStoc: %s",
                            rowData[0], rowData[1], rowData[2], rowData[3], rowData[4], rowData[5]
                    );
                    showPerfumeDetails(perfumeDetails);
                } else {
                    showParfumNotSelectedMessage();
                }
            }
        });



        btnFiltreaza.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                presenter.handleFilterParfums();
            }
        });


        presenter.displayParfumList();
        setVisible(true);
    }


    @Override
     public String getSelectedMagazinName() {
        if (comboBoxMagazin.getSelectedIndex() != -1) {
            return (String) comboBoxMagazin.getSelectedItem();
        }
        return "";
    }

    @Override
    public int getIdMagazin() {
        return presenter.getMagazinIdByName();
    }

    @Override
    public void setProducatorList(List<String> producators) {
        comboBoxProducator.removeAllItems();
        comboBoxProducator.addItem("Toți producătorii");
        for (String producator : producators) {
            comboBoxProducator.addItem(producator);
        }
    }


    @Override
    public Object[] getRowData(JTable table, int row) {
        int columnCount = table.getColumnCount();
        Object[] rowData = new Object[columnCount];

        for (int i = 0; i < columnCount; i++) {
            rowData[i] = table.getValueAt(row, i);
        }

        return rowData;
    }


    @Override
    public String getPriceMin() {
        return textFieldPretMin.getText().trim();
    }

    @Override
    public String getPriceMax() {
        return textFieldPretMax.getText().trim();
    }

    @Override
    public String getSelectedProducator() {
        if (comboBoxProducator.getSelectedIndex() > 0) {
            return (String) comboBoxProducator.getSelectedItem();
        }
        return "";
    }

    @Override
    public boolean isDisponibilSelected() {
        return chckbxDisponibil.isSelected();
    }


    @Override
    public int getSelectedParfumId() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            return Integer.parseInt(table.getValueAt(selectedRow, 0).toString());
        } else {
            return -1;
        }
    }

    @Override
    public void setMagazinList(List<String> magazinNames) {
        comboBoxMagazin.removeAllItems();
        for (String magazinName : magazinNames) {
            comboBoxMagazin.addItem(magazinName);
        }
    }

    @Override
    public boolean isSortByPriceAscending() {
        return comboBoxSortarePret.getSelectedItem().equals("Crescător");
    }

    @Override
    public boolean isSortByNameAscending() {
        return comboBoxSortareNume.getSelectedItem().equals("Crescător");
    }


    @Override
    public void showParfumNotFoundMessage(){
        JOptionPane.showMessageDialog(this, "Nu s-a găsit parfumul introdus. Vă rugăm încercați din nou ");
    }
    @Override
    public void showParfumNotSelectedMessage(){
        JOptionPane.showMessageDialog(this, "Selectați un parfum pentru a vizualiza detaliile.");
    }

    @Override
    public String getEnteredParfumName() {
        return textFieldCautaDupaNume.getText();
    }

    @Override
    public void showPerfumeDetailsByName(String perfumeDetails) {
        String[] perfumeDetailsArray = perfumeDetails.split("\n");

        String[] columnNames = {
                "ID", "Nume", "Producator", "Pret", "Descriere"
        };

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.5;
        gbc.weighty = 0.5;
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.insets = new Insets(10, 10, 10, 10);

        Font boldFont = new Font("Times New Roman", Font.BOLD, 16);
        Font normalFont = new Font("Times New Roman", Font.PLAIN, 14);

        for (int i = 0; i < columnNames.length; i++) {
            JLabel label = new JLabel(columnNames[i] + ":");
            label.setFont(boldFont);
            panel.add(label, gbc);
            gbc.gridy++;
        }

        gbc.gridx = 1;
        gbc.gridy = 0;
        for (int i = 0; i < perfumeDetailsArray.length; i++) {
            String detail = perfumeDetailsArray[i];
            if (i == 4) { // Description field
                JTextArea descriptionTextArea = new JTextArea(detail.substring(detail.indexOf(':') + 1).trim());
                descriptionTextArea.setFont(normalFont);
                descriptionTextArea.setLineWrap(true);
                descriptionTextArea.setWrapStyleWord(true);
                descriptionTextArea.setEditable(false);
                descriptionTextArea.setOpaque(false);
                descriptionTextArea.setBackground(Color.WHITE);

                JScrollPane scrollPane = new JScrollPane(descriptionTextArea);
                scrollPane.setPreferredSize(new Dimension(450, 100));
                panel.add(scrollPane, gbc);
            } else {
                JLabel label = new JLabel(detail.substring(detail.indexOf(':') + 1).trim());
                label.setFont(normalFont);
                panel.add(label, gbc);
            }
            gbc.gridy++;
        }

        JOptionPane.showMessageDialog(this, panel, "Detalii Parfum", JOptionPane.PLAIN_MESSAGE);
    }


    @Override
    public void showPerfumeDetails(String perfumeDetails) {
        String[] perfumeDetailsArray = perfumeDetails.split("\n");

        String[] columnNames = {
                "ID", "Nume", "Producator", "Pret", "Descriere", "Stoc"
        };

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.5;
        gbc.weighty = 0.5;
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.insets = new Insets(10, 10, 10, 10);

        Font boldFont = new Font("Times New Roman", Font.BOLD, 16);
        Font normalFont = new Font("Times New Roman", Font.PLAIN, 14);

        for (int i = 0; i < columnNames.length; i++) {
            JLabel label = new JLabel(columnNames[i] + ":");
            label.setFont(boldFont);
            panel.add(label, gbc);
            gbc.gridy++;
        }

        gbc.gridx = 1;
        gbc.gridy = 0;
        for (int i = 0; i < perfumeDetailsArray.length; i++) {
            String detail = perfumeDetailsArray[i];
            if (i == 4) { // Description field
                JTextArea descriptionTextArea = new JTextArea(detail.substring(detail.indexOf(':') + 1).trim());
                descriptionTextArea.setFont(normalFont);
                descriptionTextArea.setLineWrap(true);
                descriptionTextArea.setWrapStyleWord(true);
                descriptionTextArea.setEditable(false);
                descriptionTextArea.setOpaque(false);
                descriptionTextArea.setBackground(Color.WHITE);

                JScrollPane scrollPane = new JScrollPane(descriptionTextArea);
                scrollPane.setPreferredSize(new Dimension(450, 100));
                panel.add(scrollPane, gbc);
            } else {
                JLabel label = new JLabel(detail.substring(detail.indexOf(':') + 1).trim());
                label.setFont(normalFont);
                panel.add(label, gbc);
            }
            gbc.gridy++;
        }

        JOptionPane.showMessageDialog(this, panel, "Detalii Parfum", JOptionPane.PLAIN_MESSAGE);
    }


    public void displayParfumList(Object[][] parfumList) {
        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
        tableModel.setRowCount(0);

        for (Object[] row : parfumList) {
            tableModel.addRow(row);
        }
    }

}