package View;

public interface ILogin {

    String getUser();
    String getParola();
    void mesajEroare();
    void setAdministratorGUI(String user);
    void setManagerGUI(String user);
    void setAngajatGUI(String user, int idMagazin);

}
