package View;
import java.util.List;
public interface IManager extends IParfumView {
    boolean isSortByNameAscending();
    boolean isSortByPriceAscending();
    String getEnteredParfumName();
    void showPerfumeDetailsByName(String perfumeDetails);
    void showParfumNotFoundMessage();
    void showParfumNotSelectedMessage();
    void setMagazinList(List<String> magazinNames);
    String getSelectedMagazinName();
}