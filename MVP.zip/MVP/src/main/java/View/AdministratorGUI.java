package View;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import Presenter.AdministratorPresenter;
import javax.swing.table.DefaultTableModel;


public class AdministratorGUI extends JFrame implements IAdministrator {

    private JTable userTable;
    private JTextField newUsernameField;
    private JTextField newPasswordField;
    private JComboBox<String> roleComboBox;
    private JTextField newIdField;
    private JTextField newIdMagazinField;
    private JButton addUserButton;
    private JButton deleteUserButton;
    private JButton updateUserButton;
    private JButton viewUserDetailsButton;
    private String user;

    public AdministratorGUI(String user) {
        initialize();
        setVisible(true);
        this.user=user;
        setTitle("Administrator - " + user);

    }

    private void initialize() {
        setLayout(new BorderLayout());

        setLocationRelativeTo(null);

        // User table
        userTable = new JTable();
        JScrollPane userTableScrollPane = new JScrollPane(userTable);
        userTable.setRowHeight(30);
        userTable.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        userTable.getTableHeader().setFont(new Font("Times New Roman", Font.BOLD, 16));
        add(userTableScrollPane, BorderLayout.CENTER);

        // Controls panel
        JPanel controlsPanel = new JPanel();
        controlsPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.insets = new Insets(2, 2, 2, 2);

        // User ID
        JLabel userIdLabel = new JLabel("ID User:");
        userIdLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
        controlsPanel.add(userIdLabel, gbc);
        gbc.gridx++;
        newIdField = new JTextField(10);
        controlsPanel.add(newIdField, gbc);

        // New username
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
        controlsPanel.add(usernameLabel, gbc);
        gbc.gridx++;
        newUsernameField = new JTextField(10);
        controlsPanel.add(newUsernameField, gbc);

        // New password
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel passwordLabel = new JLabel("Parola:");
        passwordLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
        controlsPanel.add(passwordLabel, gbc);
        gbc.gridx++;
        newPasswordField = new JTextField(10);
        controlsPanel.add(newPasswordField, gbc);

        // Role
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel roleLabel = new JLabel("Rol:");
        roleLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
        controlsPanel.add(roleLabel, gbc);
        gbc.gridx++;
        roleComboBox = new JComboBox<>(new String[]{"Administrator", "Manager", "Angajat"});
        controlsPanel.add(roleComboBox, gbc);

        // ID Magazin
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel idMagazinLabel = new JLabel("ID Magazin:");
        idMagazinLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
        controlsPanel.add(idMagazinLabel, gbc);
        gbc.gridx++;
        newIdMagazinField = new JTextField(10);
        controlsPanel.add(newIdMagazinField, gbc);

        // Buttons
        addUserButton = new JButton("Adaugă utilizator");
        addUserButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
        deleteUserButton = new JButton("Șterge utilizator");
        deleteUserButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
        updateUserButton = new JButton("Actualizează utilizator");
        updateUserButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
        viewUserDetailsButton = new JButton("Vizualizează detaliile unui utilizator");
        viewUserDetailsButton.setFont(new Font("Times New Roman", Font.BOLD, 14));


        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        controlsPanel.add(addUserButton, gbc);

        gbc.gridy++;
        controlsPanel.add(deleteUserButton, gbc);

        gbc.gridy++;
        controlsPanel.add(updateUserButton, gbc);

        gbc.gridy++;
        controlsPanel.add(viewUserDetailsButton, gbc);


        add(controlsPanel, BorderLayout.SOUTH);


        setSize(800, 700);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        AdministratorPresenter presenter = new AdministratorPresenter(this);

        //add
        addUserButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                presenter.addUser();
            }
        });

        // delete
        deleteUserButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                presenter.deleteUser();
            }
        });

        //update
        updateUserButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                presenter.updateUser();
            }
        });

        //view
        viewUserDetailsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = userTable.getSelectedRow();
                if (selectedRow != -1) {
                    Object[] rowData = getRowData(selectedRow);
                    String userDetails = String.format(
                            "ID User: %s\nUsername: %s\nParola: %s\nRol: %s\nID Magazin: %s",
                            rowData[0], rowData[1], rowData[2], rowData[3], rowData[4]
                    );
                    showUserDetails(userDetails);
                } else {
                    showUserNotSelectedMessage();
                }
            }
        });

        presenter.displayUserList();
    }

    @Override
    public void showSelectUserToDeleteMessage() {
        JOptionPane.showMessageDialog(this, "Selectați utilizatorul pe care doriți să îl ștergeți");
    }

    @Override
    public void showUserDeletedSuccessMessage() {
        JOptionPane.showMessageDialog(this, "Utilizator șters cu succes.");
    }

    @Override
    public void showFailedToDeleteUserMessage() {
        JOptionPane.showMessageDialog(this, "Eroare la ștergerea utilizatorului");
    }

    @Override
    public void showUserAddedSuccessMessage() {
        JOptionPane.showMessageDialog(this, "Utilizator adăugat cu succes.");
    }

    @Override
    public void showFailedToAddUserMessage() {
        JOptionPane.showMessageDialog(this, "Eroare la adăugarea utilizatorului");
    }

    @Override
    public void showSelectUserToUpdateMessage() {
        JOptionPane.showMessageDialog(this, "Selectați utilizatorul pe care doriți să îl actualizați");
    }

    @Override
    public void showUserUpdatedSuccessMessage() {
        JOptionPane.showMessageDialog(this, "Utilizator actualizat cu succes.");
    }

    @Override
    public void showFailedToUpdateUserMessage() {
        JOptionPane.showMessageDialog(this, "Eroare la actualizarea utilizatorului");
    }

    @Override
    public void showUserNotSelectedMessage() {
        JOptionPane.showMessageDialog(this, "Vă rugăm să selectați un utilizator pentru a-i vedea detaliile.");
    }

        @Override
        public int getUserId() {
            try {
                return Integer.parseInt(newIdField.getText());
            } catch (NumberFormatException e) {
                return -1;
            }
        }

        @Override
        public String getUserName() {
            return newUsernameField.getText();
        }

        @Override
        public String getPassword() {
            return newPasswordField.getText();
        }

        @Override
        public String getRol() {
            return (String) roleComboBox.getSelectedItem();
        }

        @Override
        public int getIdMagazin() {
            try {
                return Integer.parseInt(newIdMagazinField.getText());
            } catch (NumberFormatException e) {
                return -1;
            }
        }


        @Override
        public int getSelectedUserId() {
            int selectedRow = userTable.getSelectedRow();
            if (selectedRow != -1) {
                return Integer.parseInt(userTable.getValueAt(selectedRow, 0).toString());
            } else {
                return -1;
            }
        }



        @Override
        public Object[] getRowData(int row) {
            int columnCount = userTable.getColumnCount();
            Object[] rowData = new Object[columnCount];

            for (int i = 0; i < columnCount; i++) {
                rowData[i] = userTable.getValueAt(row, i);
            }

            return rowData;
        }



        @Override
        public void displayUsers(Object[][] users) {
            DefaultTableModel model = new DefaultTableModel(users, new Object[]{"ID user", "Username", "Parolă", "Magazin", "ID magazin"});
            userTable.setModel(model);
        }

        @Override
        public void showUserDetails(String userDetails) {
            JFrame userDetailsWindow = new JFrame("User Details");
            userDetailsWindow.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            userDetailsWindow.setSize(500, 500);
            userDetailsWindow.setLocationRelativeTo(null);

            JTextArea userDetailsTextArea = new JTextArea(userDetails);
            userDetailsTextArea.setFont(new Font("Times New Roman", Font.BOLD, 14));
            userDetailsTextArea.setEditable(false);
            userDetailsTextArea.setBackground(Color.WHITE);
            userDetailsTextArea.setLineWrap(true);
            userDetailsTextArea.setWrapStyleWord(true);

            JScrollPane userDetailsScrollPane = new JScrollPane(userDetailsTextArea);
            userDetailsWindow.add(userDetailsScrollPane);

            userDetailsWindow.setVisible(true);
        }





    }
