package View;


public interface IAdministrator {
    int getUserId();
    String getUserName();
    String getPassword();
    String getRol();
    int getSelectedUserId();
    void displayUsers(Object[][] users);

    void showSelectUserToDeleteMessage();
    void showUserDeletedSuccessMessage();
    void showFailedToDeleteUserMessage();
    void showUserAddedSuccessMessage();
    void showFailedToAddUserMessage();
    void showSelectUserToUpdateMessage();
    void showUserUpdatedSuccessMessage();
    void showFailedToUpdateUserMessage();
    void showUserNotSelectedMessage();

    int getIdMagazin();

    Object[] getRowData(int row);

    void showUserDetails(String userDetails);



}
