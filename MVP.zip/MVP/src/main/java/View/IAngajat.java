package View;

public interface IAngajat extends IParfumView {
    int getIdParfum();
    int getStoc();
    int getNewIdParfum();
    String getNewNume();
    String getNewProducator();
    double getNewPret();
    String getNewDescriere();
    int getNewStoc();
    void showParfumUpdatedSuccessMessage();
    void showFailedToUpdateParfumMessage();
    void showParfumNotSelectedMessage();
    void showParfumAddedSuccessMessage();
    void showFailedToAddParfumMessage();
    void showParfumDeletedSuccessMessage();
    void showFailedToDeleteParfumMessage();
    void showIdStocInvalidMessage();

}


