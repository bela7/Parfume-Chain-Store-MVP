package Model;

public class Utilizator {
    private int userId;
    private String user;
    private String parola;
    private String rol;
    private int idMagazin;

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getParola() {
        return parola;
    }

    public void setParola(String parola) {
        this.parola = parola;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }
    public int getIdMagazin() {
        return idMagazin;
    }

    public void setIdMagazin(int idMagazin) {
        this.idMagazin = idMagazin;
    }
}
