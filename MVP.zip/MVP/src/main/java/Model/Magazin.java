package Model;
public class Magazin {
    private int idMagazin;
    private String nume;
    private String adresa;

    public Magazin() {
    }

    public Magazin(int idMagazin, String nume, String adresa) {
        this.idMagazin = idMagazin;
        this.nume = nume;
        this.adresa = adresa;
    }

    public int getIdMagazin() {
        return idMagazin;
    }

    public void setIdMagazin(int idMagazin) {
        this.idMagazin = idMagazin;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }
}
