package Model;

public class Parfum {
    private int idParfum;
    private String nume;
    private String producator;
    private double pret;
    private String descriere;
    public Parfum() {
    }

    public Parfum(int parfumId, String nume, String producator, double pret, String descriere) {
        this.idParfum = parfumId;
        this.nume = nume;
        this.producator = producator;
        this.pret = pret;
        this.descriere = descriere;
    }

    public int getIdParfum() {
        return idParfum;
    }

    public void setIdParfum(int userId) {
        this.idParfum = userId;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getProducator() {
        return producator;
    }

    public void setProducator(String producator) {
        this.producator = producator;
    }

    public double getPret() {
        return pret;
    }

    public void setPret(double pret) {
        this.pret = pret;
    }

    public String getDescriere() {
        return descriere;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }
}
