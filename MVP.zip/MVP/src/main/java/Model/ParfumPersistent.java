package Model;

import java.util.ArrayList;
import java.util.List;
import java.sql.*;

public class ParfumPersistent extends Persistent<Parfum> {
    private List<Parfum> parfumList = new ArrayList<>();
    private List<ParfumMagazin> parfumMagazinList = new ArrayList<>();

    public boolean create(Parfum parfum) {
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        boolean success = false;

        try {
            conn = DatabaseConnection.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

        String query = "INSERT INTO Parfum (idParfum, nume, producator, pret, descriere) VALUES (?, ?, ?, ?, ?)";

        try {
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, parfum.getIdParfum());
            statement.setString(2, parfum.getNume());
            statement.setString(3, parfum.getProducator());
            statement.setDouble(4, parfum.getPret());
            statement.setString(5, parfum.getDescriere());

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Parfum read(int id) {
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            conn = DatabaseConnection.getConnection();
            String query = "SELECT * FROM Parfum WHERE idParfum = ?";
            preparedStatement = conn.prepareStatement(query);
            preparedStatement.setInt(1, id);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int idParfum = resultSet.getInt("idParfum");
                String nume = resultSet.getString("nume");
                String producator = resultSet.getString("producator");
                double pret = resultSet.getDouble("pret");
                String descriere = resultSet.getString("descriere");

                return new Parfum(idParfum, nume, producator, pret, descriere);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    public Parfum readByName(String name) {
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            conn = DatabaseConnection.getConnection();
            String query = "SELECT * FROM Parfum WHERE nume = ?";
            preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString(1, name);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int idParfum = resultSet.getInt("idParfum");
                String nume = resultSet.getString("nume");
                String producator = resultSet.getString("producator");
                double pret = resultSet.getDouble("pret");
                String descriere = resultSet.getString("descriere");

                return new Parfum(idParfum, nume, producator, pret, descriere);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }


    @Override
    public boolean update(Parfum parfum) {
        boolean updated = false;

        try {
            Connection conn = DatabaseConnection.getConnection();

            String sql = "UPDATE parfum SET nume=?, producator=?, pret=?, descriere=? WHERE idParfum=?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);

            preparedStatement.setString(1, parfum.getNume());
            preparedStatement.setString(2, parfum.getProducator());
            preparedStatement.setDouble(3, parfum.getPret());
            preparedStatement.setString(4, parfum.getDescriere());
            preparedStatement.setInt(5, parfum.getIdParfum());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                updated = true;
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return updated;
    }


    @Override
    public boolean delete(int idParfum) {
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        boolean success = false;

        try {
            conn = DatabaseConnection.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

        String query = "DELETE FROM Parfum WHERE idParfum = ?";

        try {
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, idParfum);

            int rowsAffected = statement.executeUpdate();
            success = rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return success;
    }



    public List<String> getAllProducators(int idmagazin) {
        List<String> producators = new ArrayList<>();

        String sql = "SELECT DISTINCT p.producator " +
                "FROM parfum p " +
                "JOIN parfummagazin pm ON p.idparfum = pm.idparfum " +
                "WHERE pm.idmagazin = ? " +
                "ORDER BY p.producator";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idmagazin);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String producator = rs.getString("producator");
                producators.add(producator);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return producators;
    }

    @Override
    public List<Parfum> getAll() {
        List<Parfum> parfums = new ArrayList<>();

        try {
            Connection conn = DatabaseConnection.getConnection();

            String sql = "SELECT * FROM parfum";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Parfum parfum = new Parfum(
                        resultSet.getInt("idParfum"),
                        resultSet.getString("nume"),
                        resultSet.getString("producator"),
                        resultSet.getDouble("pret"),
                        resultSet.getString("descriere")
                );
                parfums.add(parfum);
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return parfums;
    }


    public List<ParfumMagazin> getAllParfumuriForMagazin(int idMagazin) {
        List<ParfumMagazin> parfumuriMagazin = new ArrayList<>();

        try {
            Connection conn = DatabaseConnection.getConnection();

            String sql = "SELECT p.idparfum, p.nume, p.producator, p.pret, p.descriere, pm.stoc " +
                    "FROM parfum p " +
                    "JOIN parfummagazin pm ON p.idparfum = pm.idparfum " +
                    "WHERE pm.idmagazin = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, idMagazin);

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Parfum parfum = new Parfum();
                parfum.setIdParfum(resultSet.getInt("idparfum"));
                parfum.setNume(resultSet.getString("nume"));
                parfum.setProducator(resultSet.getString("producator"));
                parfum.setPret(resultSet.getDouble("pret"));
                parfum.setDescriere(resultSet.getString("descriere"));

                ParfumMagazin parfumMagazin = new ParfumMagazin();
                parfumMagazin.setParfum(parfum);
                parfumMagazin.setStoc(resultSet.getInt("stoc"));

                parfumuriMagazin.add(parfumMagazin);
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return parfumuriMagazin;
    }

    public List<ParfumMagazin> filterParfums(int idMagazin, Double priceMin, Double priceMax, String producator, Boolean disponibil) {
        List<ParfumMagazin> filteredParfums = new ArrayList<>();

        try {
            Connection conn = DatabaseConnection.getConnection();

            StringBuilder sql = new StringBuilder(
                    "SELECT p.idparfum, p.nume, p.producator, p.pret, p.descriere, pm.stoc " +
                            "FROM parfum p " +
                            "JOIN parfummagazin pm ON p.idparfum = pm.idparfum " +
                            "WHERE pm.idmagazin = ?");

            if (priceMin != null) {
                sql.append(" AND p.pret >= ?");
            }

            if (priceMax != null) {
                sql.append(" AND p.pret <= ?");
            }

            if (producator != null && !producator.isEmpty()) {
                sql.append(" AND p.producator = ?");
            }

            if (disponibil != null) {
                sql.append(" AND pm.stoc " + (disponibil ? "> 0" : "= 0"));
            }

            PreparedStatement preparedStatement = conn.prepareStatement(sql.toString());
            preparedStatement.setInt(1, idMagazin);

            int index = 2;
            if (priceMin != null) {
                preparedStatement.setDouble(index++, priceMin);
            }
            if (priceMax != null) {
                preparedStatement.setDouble(index++, priceMax);
            }
            if (producator != null && !producator.isEmpty()) {
                preparedStatement.setString(index++, producator);
            }

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Parfum parfum = new Parfum();
                parfum.setIdParfum(resultSet.getInt("idparfum"));
                parfum.setNume(resultSet.getString("nume"));
                parfum.setProducator(resultSet.getString("producator"));
                parfum.setPret(resultSet.getDouble("pret"));
                parfum.setDescriere(resultSet.getString("descriere"));

                ParfumMagazin parfumMagazin = new ParfumMagazin();
                parfumMagazin.setParfum(parfum);
                parfumMagazin.setStoc(resultSet.getInt("stoc"));
                parfumMagazin.setDisponibilitate(resultSet.getInt("stoc") > 0);

                filteredParfums.add(parfumMagazin);
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return filteredParfums;
    }


    public List<ParfumMagazin> getSortedParfumsByName(int idMagazin, boolean ascending) {
        List<ParfumMagazin> sortedParfums = new ArrayList<>();

        try {
            Connection conn = DatabaseConnection.getConnection();

            String sql = "SELECT p.idparfum, p.nume, p.producator, p.pret, p.descriere, pm.stoc " +
                    "FROM parfum p " +
                    "JOIN parfummagazin pm ON p.idparfum = pm.idparfum " +
                    "WHERE pm.idmagazin = ? " +
                    "ORDER BY p.nume " + (ascending ? "ASC" : "DESC");

            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, idMagazin);

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Parfum parfum = new Parfum();
                parfum.setIdParfum(resultSet.getInt("idparfum"));
                parfum.setNume(resultSet.getString("nume"));
                parfum.setProducator(resultSet.getString("producator"));
                parfum.setPret(resultSet.getDouble("pret"));
                parfum.setDescriere(resultSet.getString("descriere"));

                ParfumMagazin parfumMagazin = new ParfumMagazin();
                parfumMagazin.setParfum(parfum);
                parfumMagazin.setStoc(resultSet.getInt("stoc"));
                parfumMagazin.setDisponibilitate(resultSet.getInt("stoc") > 0);

                sortedParfums.add(parfumMagazin);
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return sortedParfums;
    }
    public List<ParfumMagazin> getSortedParfumsByPrice(int idMagazin, boolean ascending) {
        List<ParfumMagazin> sortedParfums = new ArrayList<>();

        try {
            Connection conn = DatabaseConnection.getConnection();

            String sql = "SELECT p.idparfum, p.nume, p.producator, p.pret, p.descriere, pm.stoc " +
                    "FROM parfum p " +
                    "JOIN parfummagazin pm ON p.idparfum = pm.idparfum " +
                    "WHERE pm.idmagazin = ? " +
                    "ORDER BY p.pret " + (ascending ? "ASC" : "DESC");

            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, idMagazin);

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Parfum parfum = new Parfum();
                parfum.setIdParfum(resultSet.getInt("idparfum"));
                parfum.setNume(resultSet.getString("nume"));
                parfum.setProducator(resultSet.getString("producator"));
                parfum.setPret(resultSet.getDouble("pret"));
                parfum.setDescriere(resultSet.getString("descriere"));

                ParfumMagazin parfumMagazin = new ParfumMagazin();
                parfumMagazin.setParfum(parfum);
                parfumMagazin.setStoc(resultSet.getInt("stoc"));
                parfumMagazin.setDisponibilitate(resultSet.getInt("stoc") > 0);

                sortedParfums.add(parfumMagazin);
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return sortedParfums;
    }


    }
